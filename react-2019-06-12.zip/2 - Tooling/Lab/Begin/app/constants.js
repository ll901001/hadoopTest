export default {
    moviesLoaded: "MOVIES-LOADED",
  movieSaved: "MOVIE-SAVED"
};
