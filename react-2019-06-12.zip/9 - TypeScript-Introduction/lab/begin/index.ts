(function() {
  'use strict';

  class RPNCalculator {
    // Implement this class.
  }

  new RPNCalculator(document);
})();
